// commands/welcome.js
const fs = require('fs');
const path = require('path');

const welcomeDB = path.join(__dirname, '../welcome-db.json');

module.exports = {
    name: 'welcome',
    aliases: [],
    desc: 'Activa o desactiva el sistema de bienvenida',
    execute: async (sock, msg, args) => {
        if (!msg.key.remoteJid.endsWith("@g.us")) return;

        const metadata = await sock.groupMetadata(msg.key.remoteJid);
        const participants = metadata.participants;
        const sender = msg.key.participant;
        const senderIsAdmin = participants.find(p => p.id === sender)?.admin !== null;

        if (!senderIsAdmin) return await sock.sendMessage(msg.key.remoteJid, {
            text: "⚠️ Solo administradores pueden usar este comando.",
            quoted: msg
        });

        const db = JSON.parse(fs.readFileSync(welcomeDB));

        const option = (args[0] || '').toLowerCase();
        if (!['on','off'].includes(option)) return await sock.sendMessage(msg.key.remoteJid, {
            text: "Uso: *.welcome on* o *.welcome off*",
            quoted: msg
        });

        db[msg.key.remoteJid] = option === 'on';
        fs.writeFileSync(welcomeDB, JSON.stringify(db, null, 2));

        await sock.sendMessage(msg.key.remoteJid, {
            text: `✅ Sistema de bienvenida ${option === 'on' ? 'activado' : 'desactivado'} correctamente.`,
            quoted: msg
        });
    }
}