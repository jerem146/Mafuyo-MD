const fs = require("fs");
const path = require("path");

const muteDB = path.join(__dirname, "../mute-db.json");
if (!fs.existsSync(muteDB)) fs.writeFileSync(muteDB, JSON.stringify({}));

module.exports = {
    name: "mute",
    aliases: ["silenciar", "callar"],
    description: "Silencia a un participante para borrar automáticamente sus mensajes",

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;

        if (!from.endsWith("@g.us")) {
            return sock.sendMessage(from, { text: "❌ Este comando solo funciona en grupos." });
        }

        // Datos del grupo
        const metadata = await sock.groupMetadata(from);
        const participants = metadata.participants;

        const sender = msg.key.participant;
        const isAdmin = participants.find(p => p.id === sender)?.admin !== null;

        if (!isAdmin) {
            return sock.sendMessage(from, { text: "😿 *Debes ser administrador para usar este comando.*" });
        }

        // === NUEVO: detectar usuario por:
        // 1) Etiqueta
        // 2) Responder mensaje

        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        const replyUser = msg.message?.extendedTextMessage?.contextInfo?.participant;

        const target = mentioned || replyUser;

        if (!target) {
            return sock.sendMessage(from, { 
                text: "⚠️ Debes mencionar o responder a alguien.\nEjemplo:\n.mute @usuario" 
            });
        }

        // Cargar BD
        const db = JSON.parse(fs.readFileSync(muteDB));
        if (!db[from]) db[from] = {};

        db[from][target] = {
            muted: true,
            strikes: 0,
            warned: false
        };

        fs.writeFileSync(muteDB, JSON.stringify(db, null, 2));

        await sock.sendMessage(from, {
            text: `🔇 Usuario silenciado:\n@${target.split("@")[0]}`,
            mentions: [target]
        });
    }
};