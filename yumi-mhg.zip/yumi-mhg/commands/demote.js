// commands/demote.js
module.exports = {
    name: "demote",
    aliases: ["quitaradmin", "degradar"],

    async execute(sock, msg, args) {
        try {
            const from = msg.key.remoteJid;
            if (!from.endsWith("@g.us"))
                return await sock.sendMessage(from, { text: "❀ Este comando solo puede usarse en grupos." });

            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants;

            const botNumber = sock.user.id.split(":")[0] + "@s.whatsapp.net";
            const isBotAdmin = participants.find(p => p.id === botNumber)?.admin !== null;

            const sender = msg.key.participant || msg.key.remoteJid;
            const isSenderAdmin = participants.find(p => p.id === sender)?.admin !== null;

            // Validaciones
            if (!isSenderAdmin)
                return await sock.sendMessage(from, { text: "❀ Solo un administrador puede quitar roles de administrador." });

            if (!isBotAdmin)
                return await sock.sendMessage(from, { text: "❀ No puedo modificar roles si no soy administrador." });

            // Determinar el objetivo
            let target;

            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
                // Mención
                target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];

            } else if (
                msg.message?.extendedTextMessage?.contextInfo?.participant &&
                msg.message.extendedTextMessage.contextInfo.quotedMessage
            ) {
                // Respondiendo mensaje (quoted)
                target = msg.message.extendedTextMessage.contextInfo.participant;

            } else if (args[0]) {
                // Número escrito
                target = args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";

            } else {
                return await sock.sendMessage(from, { text: `❀ Menciona, responde o coloca el número del usuario a degradar.` });
            }

            // Degradar
            await sock.groupParticipantsUpdate(from, [target], "demote");

            // Mensaje elegante
            await sock.sendMessage(from, {
                text:
`⚠️ *Administrador degradado*

👤 *Degradado:* @${target.split("@")[0]}
🛡 *Acción ejecutada por:* @${sender.split("@")[0]}

❀ El equilibrio ha sido restaurado.`,
                mentions: [target, sender]
            });

        } catch (e) {
            console.error("Error en demote:", e);
        }
    }
};