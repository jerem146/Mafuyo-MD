// ARCHIVO: commands/sticker.js (VERSIÓN FINAL CON CORRECCIÓN DE SINTAXIS)

const { downloadContentFromMessage } = require('baileys');
const { exec } = require('child_process');
const fs = require('fs/promises');
const path = require('path');
const { tmpdir } = require('os');
const webp = require('node-webpmux');
const crypto = require('crypto');

/**
 * Genera un nombre de archivo aleatorio para los archivos temporales.
 * @param {string} ext - La extensión del archivo (ej: 'webp', 'mp4').
 * @returns {string} - La ruta completa al archivo temporal.
 */
const getRandomTmpFile = (ext) => {
    const randomName = crypto.randomBytes(12).toString('hex');
    return path.join(tmpdir(), `${randomName}.${ext}`);
};

/**
 * Añade los metadatos al sticker.
 * @param {Buffer} mediaBuffer - El buffer del sticker en formato webp.
 * @param {object} metadata - Objeto con la información del autor y paquete.
 * @returns {Promise<Buffer>} - Buffer del sticker final con metadatos.
 */
async function addStickerMetadata(mediaBuffer, metadata) {
    const img = new webp.Image();
    const json = {
        "sticker-pack-id": `com.yumimhg.bot.${Date.now()}`,
        "sticker-pack-name": metadata.pack,
        "sticker-pack-publisher": metadata.author,
        "emojis": ["🤖", "✨"],
    };

    const exifAttr = Buffer.from([
        0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
        0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
    ]);
    const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
    const exif = Buffer.concat([exifAttr, jsonBuff]);
    exif.writeUIntLE(jsonBuff.length, 14, 4);

    await img.load(mediaBuffer);
    img.exif = exif;
    return await img.save(null);
}

module.exports = {
    name: 'sticker',
    aliases: ['s', 'stiker', 'f', 'fig'],
    description: 'Crea stickers de alta calidad a partir de imagen, GIF o video.',
    async execute(sock, msg, args) {
        const quoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
        const messageType = quoted ? Object.keys(quoted)[0] : Object.keys(msg.message)[0];
        const mediaMessage = quoted ? quoted : msg.message;

        if (messageType !== 'imageMessage' && messageType !== 'videoMessage') {
            return sock.sendMessage(msg.key.remoteJid, { text: 'Por favor, responde a una imagen, GIF o video para crear un sticker.' }, { quoted: msg });
        }
        
        const inputPath = getRandomTmpFile('media');
        const outputPath = getRandomTmpFile('webp');

        try {
            if (messageType === 'videoMessage') {
                const duration = mediaMessage.videoMessage.seconds;
                const maxDuration = 10;
                if (duration > maxDuration) {
                    return await sock.sendMessage(msg.key.remoteJid, { text: `El video es muy largo (${duration}s). El máximo es de ${maxDuration}s.` }, { quoted: msg });
                }
            }

            let buffer;
            for (let attempt = 1; attempt <= 3; attempt++) {
                try {
                    const stream = await downloadContentFromMessage(mediaMessage[messageType], messageType.replace('Message', ''));
                    buffer = Buffer.from([]);
                    for await (const chunk of stream) {
                        buffer = Buffer.concat([buffer, chunk]);
                    }
                    break;
                } catch (error) {
                    if (attempt === 3) {
                        throw new Error(`Fallo al descargar después de 3 intentos: ${error.message}`);
                    }
                    await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
                }
            }
            await fs.writeFile(inputPath, buffer);

            if (messageType === 'imageMessage') {
                const cmd = `ffmpeg -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0.0" -vcodec libwebp -lossless 1 -quality 90 "${outputPath}"`;
                await new Promise((resolve, reject) => exec(cmd, (err) => (err ? reject(err) : resolve())));
            } else {
                const cmd = `ffmpeg -i "${inputPath}" -t 10 -vf "fps=15,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0.0" -c:v libwebp -lossless 0 -q:v 75 -loop 0 -an -y "${outputPath}"`;
                await new Promise((resolve, reject) => exec(cmd, (err) => (err ? reject(err) : resolve())));
            }

            const authorName = msg.pushName || "Yumi-Bot";
            const metadata = { author: authorName, pack: 'Creado por Mafuyo-Bot' };
            const stickerBuffer = await fs.readFile(outputPath);
            const finalStickerBuffer = await addStickerMetadata(stickerBuffer, metadata);

            for (let attempt = 1; attempt <= 3; attempt++) {
                try {
                    await sock.sendMessage(msg.key.remoteJid, { sticker: finalStickerBuffer }, { quoted: msg });
                    break;
                } catch (error) {
                    if (attempt === 3) {
                        throw new Error(`Fallo al enviar después de 3 intentos: ${error.message}`);
                    }
                    await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
                }
            }
        } catch (error) {
            console.error('Error detallado en el comando sticker:', error);
            await sock.sendMessage(msg.key.remoteJid, { text: `Ocurrió un error al crear el sticker.\n_Error: ${error.message}_` }, { quoted: msg });
        } finally {
            await Promise.all([
                fs.unlink(inputPath).catch(() => {}),
                fs.unlink(outputPath).catch(() => {})
            ]);
        }
    }
};