// ./commands/menu.js

module.exports = {
    name: 'menu',
    aliases: ['help', 'ayuda'],
    description: 'Muestra el menú principal del bot con una imagen.',
    
    /**
     * @param {import('baileys').WASocket} sock
     *@param {import('baileys').WAMessage} msg
     */
    async execute(sock, msg) {
        
        const from = msg.key.remoteJid;
        const isGroup = from.endsWith('@g.us');
        
        // --- 1. OBTENER TODA LA INFORMACIÓN DINÁMICA ---

        const botName = sock.user.name || 'MAFUYO-BOT';
        const senderJid = msg.key.participant || msg.key.remoteJid;
        const timeFt = new Date().toLocaleString('es-PE', { timeZone: 'America/Lima' });

        let groupName = 'Chat Privado';
        if (isGroup) {
            try {
                const metadata = await sock.groupMetadata(from);
                groupName = metadata.subject;
            } catch (e) {
                console.error("Error al obtener metadata del grupo:", e);
                groupName = "Grupo Desconocido";
            }
        }

        // --- 2. CONSTRUIR EL TEXTO DEL MENÚ (AHORA SERÁ LA DESCRIPCIÓN) ---
        
        const menuCaption = `
   『 𝐌𝐄𝐍𝐔 - 𝐏𝐑𝐈𝐍𝐂𝐈𝐏𝐀𝐋 』
╭══════════════════
│❐   ➢ ${timeFt}
 ❱  〄 @${senderJid.split('@')[0]} 
│❐  ꦿ𝐒𝐎𝐘 : ${botName}
│❐  ꦿ𝙋𝙍𝙀𝙁𝙄𝙅𝙊 : . (Punto)
│❐  ꦿ𝙂𝙍𝙐𝙋𝙊 : ${groupName}
│╰───────────────❍
╰━━━━━─「✪」─━━━━━
✪  𝙇𝙄𝙎𝙏𝘼 𝘿𝙀 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎
  ━━━━━─「✪」─━━━━━

❖ 𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐃𝐈𝐒𝐏𝐎𝐍𝐈𝐁𝐋𝐄𝐒 ❖
━━━━━━━━━━━━━━━━━

╭─❖ 𝙈𝙀𝙉𝙐 𝘼𝘿𝙈𝙄𝙉 ❖
│
┃ 🔸 *welcome on/off*
│   Activa o desactiva bienvenida.
│
┃ 🔸 *antilink on/off*
│   Borra links y castiga al usuario.
│
┃ 🔸 *open/close*
│   Abrir y cerrar el grupo.
│
┃ 🔸 *todos*/*invocar*/*tagall*
│   Menciona a todos en el grupo.
│
┃ 🔸 *mute* [mención / etiquetar]
│   El bot elimina los mensajes del
│   usuario. 
│
┃ 🔸 *unmute* [mención / etiquetar]
│   El bot deja de eliminar los
│   mensajes del usuario.
│   
┃ 🔸 *ban*/*kick* [mención/etiquetar]
│   Expulsa del grupo.
│
┃ 🔸 *promote* [mención / etiquetar]
│   Asciende a administrador.
│
┃ 🔸 *demote* [mención / etiquetar]
│   Quita los permisos de admin.
│
┃ 🔸 *tag* <texto>
│   Menciona a todos con un texto.
╰────────────────❖

╭─❖ 𝙈𝙀𝙉𝙐 𝘿𝙀𝙎𝘾𝘼𝙍𝙂𝘼𝙎 ❖
│
│ 🔹 *play* <nombre/link>
│   Descarga música.
│
│ 🔹 *tts-tiktok* <link>
│   Convierte texto en voz TikTok.
│
│ 🔹 *ttaudio* <link>
│   Descarga únicamente el audio.
│
│ 🔹 *pinterest/psearch/pin* 
│   Busca imágenes en Pinterest.
│
│ 🔹 *pixgallery* <texto>
│   Galería variada de imágenes.
│
│ 🔹 *ytmp4* <nombre/link>
│   Descarga videos MP4.
│
│ 🔹 *ttimg / tiktokimg* <link>
│   Descarga imágenes de
│   un TikTok.
╰────────────────❖
╭─❖ 𝙈𝙀𝙉𝙐 𝙁𝙄𝙂𝙐𝙍𝙄𝙏𝘼𝙎 ❖
│
│ 🔸 *sticker / s*
│   Convierte foto/video en sticker.
│
│ 🔸 *toimg*
│   Convierte sticker a imagen.
│
│ 🔸 *pfp*
│   Descarga foto de perfil.
╰────────────────❖
╔══ ⪻ 𝘾𝘼𝙍𝙇𝙔 | 𝘽𝙊𝙏 ⪼   ╗
    ✦ 𝐒𝐢𝐞𝐦𝐩𝐫𝐞 𝐞𝐥𝐞𝐠𝐚𝐧𝐭𝐞, 𝐬𝐢𝐞𝐦𝐩𝐫𝐞 𝐚𝐭𝐞𝐧𝐭𝐨 ✦
╚═════════════════╝
`;
        // --- 3. ENVIAR EL MENSAJE CON IMAGEN Y DESCRIPCIÓN ---
        try {
            await sock.sendMessage(from, { 
                // Objeto de la imagen con la URL que proporcionaste
                image: {
                    url: 'https://i.postimg.cc/j50bLgp8/IMG-20251026-WA2962.jpg'
                },
                // El texto del menú ahora va en 'caption'
                caption: menuCaption.trim(),
                // Las menciones son necesarias para que el @tag funcione
                mentions: [senderJid]
            }, { 
                // Citamos el mensaje original que activó el comando
                quoted: msg 
            });
        } catch (error) {
            console.error("Error al enviar el menú con imagen:", error);
            // Si falla el envío de la imagen, envía solo el texto como respaldo
            await sock.sendMessage(from, { text: 'Hubo un error al mostrar el menú con la imagen.' });
        }
    }
};