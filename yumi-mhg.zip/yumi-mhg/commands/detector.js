const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'detector',
    aliases: ['detect', 'avisaradmin'],
    execute: async (sock, msg, args) => {
        const detectDBPath = path.join(__dirname, '../detect-db.json');
        
        // Cargar base de datos
        let db = {};
        if (fs.existsSync(detectDBPath)) {
            db = JSON.parse(fs.readFileSync(detectDBPath));
        }

        const chatId = msg.key.remoteJid;
        const option = args[0] ? args[0].toLowerCase() : '';

        // Verificar si es admin (opcional, pero recomendado)
        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        const sender = msg.key.participant;
        const isAdmin = participants.find(p => p.id === sender)?.admin !== null;

        if (!isAdmin) {
            return sock.sendMessage(chatId, { text: '❌ Solo los administradores pueden usar este comando.' }, { quoted: msg });
        }

        if (option === 'on') {
            db[chatId] = true;
            fs.writeFileSync(detectDBPath, JSON.stringify(db, null, 2));
            await sock.sendMessage(chatId, { text: '✅ *Detector de Admin ACTIVADO*.\nEl bot avisará cuando alguien sea promovido o degradado.' }, { quoted: msg });
        } else if (option === 'off') {
            delete db[chatId]; // O db[chatId] = false
            fs.writeFileSync(detectDBPath, JSON.stringify(db, null, 2));
            await sock.sendMessage(chatId, { text: '❌ *Detector de Admin DESACTIVADO*.' }, { quoted: msg });
        } else {
            await sock.sendMessage(chatId, { text: '⚠️ Usa el comando así:\n\n*.detector on* (Activar)\n*.detector off* (Desactivar)' }, { quoted: msg });
        }
    }
};