// ./commands/pfp.js

module.exports = {
    name: 'pfp',
    aliases: ['getpfp', 'fotodeperfil'],
    description: 'Obtiene y envía la foto de perfil de un usuario.',
    
    /**
     * Ejecuta el comando para obtener la foto de perfil.
     * @param {import('baileys').WASocket} sock - El socket de la conexión de Baileys.
     * @param {import('baileys').proto.IWebMessageInfo} msg - El mensaje que activó el comando.
     * @param {string[]} args - Argumentos del comando.
     */
    execute: async (sock, msg, args) => {
        try {
            let targetJid;
            const remoteJid = msg.key.remoteJid;

            // Lógica para determinar el objetivo
            // 1. Verificar si hay menciones
            const mentionedJid = msg.message.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentionedJid && mentionedJid.length > 0) {
                targetJid = mentionedJid[0];
            } 
            // 2. Verificar si es una respuesta a otro mensaje
            else if (msg.message.extendedTextMessage?.contextInfo?.quotedMessage) {
                targetJid = msg.message.extendedTextMessage.contextInfo.participant;
            } 
            // 3. Si no hay mención ni respuesta, el objetivo es el propio autor del mensaje
            else {
                targetJid = msg.key.participant || msg.key.remoteJid;
            }

            // Intentamos obtener la URL de la foto de perfil en alta resolución
            const pfpUrl = await sock.profilePictureUrl(targetJid, 'image');

            // Enviamos la imagen con un pie de foto
            await sock.sendMessage(remoteJid, {
                image: { url: pfpUrl },
                caption: `Aquí tienes la foto de perfil ✨`
            }, { quoted: msg }); // Citamos el mensaje original para dar contexto

        } catch (error) {
            console.error('Error en el comando pfp:', error);
            // Enviamos un mensaje de error si no se pudo obtener la foto
            // Esto suele pasar si el usuario no tiene foto de perfil o la tiene privada.
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ No pude obtener la foto de perfil. Es posible que el usuario no tenga una o la haya eliminado.'
            }, { quoted: msg });
        }
    }
};