// Archivo: commands/play.js

const axios = require("axios");

// La API Key que nos proporcionaste
const API_KEY_TED = "tedzinho";

module.exports = {
    name: 'play',
    description: 'Busca, descarga y envía una canción.',
    execute: async (sock, m, args) => {
        // Mapeamos las variables a como las usa el código original
        const from = m.key.remoteJid;
        const Info = m;

        // Función de ayuda para responder rápidamente
        const reply = (texto) => sock.sendMessage(from, { text: texto }, { quoted: Info });

        try {
            const query = args.join(" ");
            if (!query) return reply(`❌ ¿Cuál es el nombre de la canción?\nEjemplo: !play Queen - Bohemian Rhapsody`);

            // --- INICIO DEL CÓDIGO ORIGINAL ADAPTADO ---

            // Función para formatear números (1000 -> 1K, 1000000 -> 1M)
            const formatarNumero = (num) => {
                if (!num) return "0";
                num = typeof num === "string" ? parseInt(num.replace(/\D/g, "")) : num;
                if (isNaN(num)) return "0";
                if (num < 1000) return num.toString();
                if (num < 1_000_000) return (num / 1000).toFixed(1).replace(/\.0$/, '') + "K";
                if (num < 1_000_000_000) return (num / 1_000_000).toFixed(1).replace(/\.0$/, '') + "M";
                return (num / 1_000_000_000).toFixed(1).replace(/\.0$/, '') + "B";
            };

            // Función genérica para enviar la música (usada por las rutas V3, V5, V8)
            const enviarMusica = async (dados, versao) => {
                const title = dados.title || dados.titulo || "Sin título";
                const author = dados.channel || dados.autor || "Desconhecido";
                const duration = dados.timestamp || dados.duracao || "Desconhecida";
                const thumbnail = dados.thumbnails?.[0] || dados.thumbnail || "https://files.catbox.moe/427zyd.jpg";
                const views = formatarNumero(dados.viewsCount || dados.views || 0);
                const publicado = dados.uploadDate || dados.publicado || "Desconhecido";
                const linkVideo = dados.videoUrl || dados.url || "N/A";
                const arquivo = dados.arquivo || dados.audioUrl;

                const legenda = `🎵 *${title}*\n👤 *Canal:* ${author}\n⏱️ *Duración:* ${duration}\n👀 *Vistas:* ${views}\n📅 *Publicado:* ${publicado}\n🔗 *Link:* ${linkVideo}\n📡 *Ruta usada: ${versao}*`;

                await sock.sendMessage(from, { image: { url: thumbnail }, caption: legenda }, { quoted: Info });
                const audioBuffer = await axios.get(arquivo, { responseType: "arraybuffer" }).then(r => r.data).catch(() => null);
                if (!audioBuffer) return reply("❌ Fallo al descargar el audio.");
                await sock.sendMessage(from, { audio: audioBuffer, mimetype: "audio/mpeg", fileName: `${title}.mp3` }, { quoted: Info });
            };

            // Definimos las rutas a probar en orden
            const rotas = [
                { nome: "V1", emoji: "1️⃣" },
                { nome: "V5", emoji: "2️⃣" },
                { nome: "V3", emoji: "3️⃣" },
                { nome: "V8", emoji: "4️⃣" },
            ];

            let rotaUsada = null;

            for (const r of rotas) {
                await sock.sendMessage(from, { react: { text: r.emoji, key: Info.key } });

                try {
                    const apiURL = `https://tedzinho.com.br/api/download/play_audio/${r.nome.toLowerCase()}?apikey=${API_KEY_TED}&nome_url=${encodeURIComponent(query)}`;
                    const res = await axios.get(apiURL);
                    const data = res.data;

                    if (!data || data.status !== "OK" || !data.resultado) throw new Error("Sin resultados válidos");
                    
                    const resultado = data.resultado;

                    // La ruta V1 tiene una respuesta y lógica diferente, la manejamos por separado
                    if (r.nome === "V1") {
                        const caption = `🎧 *TOCANDO AHORA*\n` +
                                        `━━━━━━━━━━━━━━━━━━━━\n` +
                                        `📀 *Título:* ${resultado.title}\n` +
                                        `👤 *Canal:* ${resultado.channel}\n` +
                                        `⏰ *Duración:* ${resultado.timestamp}\n` +
                                        `👁️ *Vistas:* ${formatarNumero(resultado.views)}\n` +
                                        `📅 *Publicado:* ${resultado.uploadDate}\n` +
                                        `🔗 *YouTube:* ${resultado.videoUrl}\n` +
                                        `📡 *Ruta usada:* ${r.nome}\n` +
                                        `━━━━━━━━━━━━━━━━━━━━`;

                        await sock.sendMessage(from, { image: { url: resultado.thumbnails[0] }, caption }, { quoted: Info });
                        await sock.sendMessage(from, { audio: { url: resultado.dl_link.url }, mimetype: 'audio/mpeg', fileName: `${resultado.title}.mp3` }, { quoted: Info });

                    } else { // Las otras rutas (V3, V5, V8) usan la función genérica
                        await enviarMusica(resultado, r.nome);
                    }
                    
                    rotaUsada = r.nome;
                    break; // Si una ruta funciona, salimos del bucle

                } catch (e) {
                    console.error(`Error en la ruta ${r.nome}:`, e.message);
                }
            }

            if (!rotaUsada) return reply("❌ No se pudo descargar la canción. Ninguna ruta funcionó.");

            // --- FIN DEL CÓDIGO ORIGINAL ADAPTADO ---

        } catch (e) {
            console.error(e);
            await reply("❌ Ocurrió un error al procesar tu solicitud.");
        }
    },
};