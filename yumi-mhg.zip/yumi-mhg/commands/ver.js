// commands/ver.js
const { downloadContentFromMessage } = require("baileys");

module.exports = {
    name: "ver",
    aliases: ["vermsg", "open"],
    description: "Permite ver fotos o videos enviados para ver solo una vez.",

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;

        // Verificar que sea respuesta
        const ctx = msg.message?.extendedTextMessage?.contextInfo;
        if (!ctx) {
            return sock.sendMessage(from, {
                text: "📌 *Debes responder* a una foto o video de *visualización única*."
            });
        }

        let quoted = ctx.quotedMessage;
        if (!quoted) {
            return sock.sendMessage(from, { text: "❗ No pude leer el mensaje respondido." });
        }

        // ===============================
        // 🔍 NORMALIZAR EL MENSAJE CITADO
        // ===============================
        // A veces viene dentro de varios envoltorios
        if (quoted.ephemeralMessage) quoted = quoted.ephemeralMessage.message;
        if (quoted.viewOnceMessage) quoted = quoted.viewOnceMessage.message;
        if (quoted.viewOnceMessageV2) quoted = quoted.viewOnceMessageV2.message;

        // ===============================
        // 📸 FOTO
        // ===============================
        if (quoted?.imageMessage) {
            const media = quoted.imageMessage;

            const stream = await downloadContentFromMessage(media, "image");
            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            return sock.sendMessage(from, {
                image: buffer,
                caption: ""
            });
        }

        // ===============================
        // 🎥 VIDEO
        // ===============================
        if (quoted?.videoMessage) {
            const media = quoted.videoMessage;

            const stream = await downloadContentFromMessage(media, "video");
            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            return sock.sendMessage(from, {
                video: buffer,
                caption: ""
            });
        }

        return sock.sendMessage(from, {
            text: "⚠️ Ese mensaje no contiene foto o video de visualización única."
        });
    }
};