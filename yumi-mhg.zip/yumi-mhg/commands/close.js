// commands/close.js

module.exports = {
    name: "close",
    aliases: ["cerrar", "closegrupo"],
    description: "Cierra el grupo para que solo administradores puedan enviar mensajes",

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        if (!from.endsWith("@g.us")) {
            return sock.sendMessage(from, { text: "❌ Este comando solo funciona en grupos." }, { quoted: msg });
        }

        const metadata = await sock.groupMetadata(from);
        const admins = metadata.participants.filter(p => p.admin === "admin" || p.admin === "superadmin")
                                           .map(p => p.id);

        const sender = msg.key.participant || msg.key.remoteJid;

        if (!admins.includes(sender)) {
            return sock.sendMessage(from, { text: "⚠️ Solo los *administradores* pueden cerrar el grupo." }, { quoted: msg });
        }

        await sock.groupSettingUpdate(from, "announcement");

        await sock.sendMessage(from, {
            text:
`🌑 *Grupo Cerrado*
Solo los administradores pueden enviar mensajes a partir de ahora.`
        }, { quoted: msg });
    }
};