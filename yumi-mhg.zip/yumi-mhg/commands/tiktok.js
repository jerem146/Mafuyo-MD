// Archivo: commands/tiktok.js (Actualizado - Sin audio)

const axios = require("axios");

function createCaption(title, author, duration, created_at = '') {
    return `❀ *Título:* \`${title || 'No disponible'}\`\n> ☕︎ *Autor:* ${author?.nickname || 'No disponible'}\n> ✰ *Duración:* ${duration || 'No disponible'}s${created_at ? `\n> ☁︎ *Creado:* ${created_at}` : ''}`;
}

function createSearchCaption(data) {
    return `❀ *Título:* ${data.title || 'No disponible'}\n\n☕︎ *Autor:* ${data.author?.nickname || 'Desconocido'} (@${data.author.unique_id || ''})\n✧︎ *Duración:* ${data.duration || 'No disponible'}s`;
}

module.exports = {
    name: 'tiktok',
    description: 'Busca o descarga un video de TikTok (sin audio).',
    aliases: ['tt', 'tts'],
    execute: async (sock, m, args) => {
        const from = m.key.remoteJid;
        const text = args.join(" ");
        const reply = (texto) => sock.sendMessage(from, { text: texto }, { quoted: m });

        if (!text) return reply('❀ Por favor, ingresa un enlace de TikTok o algo para buscar.');
        const isUrl = /(?:https:?\/{2})?(?:www\.|vm\.|vt\.|t\.)?tiktok\.com\/([^\s&]+)/gi.test(text);

        try {
            await sock.sendMessage(from, { react: { text: '🕒', key: m.key } });

            if (isUrl) {
                const res = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(text)}?hd=1`);
                const data = res.data?.data;

                if (!data || (!data.play && !data.images)) {
                    await sock.sendMessage(from, { react: { text: '❓', key: m.key } });
                    return reply('ꕥ Enlace inválido, video privado o sin contenido descargable.');
                }
                
                const caption = createCaption(data.title, data.author, data.duration, data.created_at);

                if (data.play) {
                    await sock.sendMessage(from, { video: { url: data.play }, caption: caption }, { quoted: m });
                } else if (data.images) {
                    reply('Este TikTok es un carrusel de imágenes. Enviando...');
                    for (const imageUrl of data.images) {
                        await sock.sendMessage(from, { image: { url: imageUrl } }, { quoted: m });
                    }
                }
                // --- LÍNEAS DE AUDIO ELIMINADAS ---

            } else {
                const res = await axios.post('https://tikwm.com/api/feed/search', { keywords: text, count: 10, cursor: 0, HD: 1 });
                const videos = res.data?.data?.videos;

                if (!videos || videos.length === 0) {
                    await sock.sendMessage(from, { react: { text: '❓', key: m.key } });
                    return reply('ꕥ No se encontraron resultados para tu búsqueda.');
                }
                
                const topResult = videos[0];
                const searchCaption = createSearchCaption(topResult);
                
                await sock.sendMessage(from, { video: { url: topResult.play }, caption: searchCaption }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '✔️', key: m.key } });

        } catch (e) {
            console.error("Error en el comando TikTok:", e);
            await sock.sendMessage(from, { react: { text: '✖️', key: m.key } });
            await reply(`⚠︎ Ocurrió un error. Es posible que la API esté fallando.`);
        }
    },
};