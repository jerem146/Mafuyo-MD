// commands/open.js

module.exports = {
    name: "open",
    aliases: ["abrir", "opengrupo"],
    description: "Abre el grupo para que todos puedan enviar mensajes",

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        if (!from.endsWith("@g.us")) {
            return sock.sendMessage(from, { text: "❌ Este comando solo funciona en grupos." }, { quoted: msg });
        }

        const metadata = await sock.groupMetadata(from);
        const admins = metadata.participants.filter(p => p.admin === "admin" || p.admin === "superadmin")
                                           .map(p => p.id);

        const sender = msg.key.participant || msg.key.remoteJid;

        if (!admins.includes(sender)) {
            return sock.sendMessage(from, { text: "⚠️ Solo los *administradores* pueden abrir el grupo." }, { quoted: msg });
        }

        await sock.groupSettingUpdate(from, "not_announcement");

        await sock.sendMessage(from, {
            text:
`🌤️ *Grupo Abierto*
Ahora todos los miembros pueden enviar mensajes libremente.`
        }, { quoted: msg });
    }
};