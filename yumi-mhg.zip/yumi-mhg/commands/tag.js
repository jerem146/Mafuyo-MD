// ARCHIVO: commands/tag.js

module.exports = {
    name: 'tag',
    aliases: ['hidetag', 'mencionar', 'tagall'],
    description: 'Menciona a todos los miembros de un grupo de forma silenciosa con un mensaje.',
    async execute(sock, msg, args) {
        const remoteJid = msg.key.remoteJid;

        // 1. Verificar si el comando se está usando en un grupo
        if (!remoteJid.endsWith('@g.us')) {
            return sock.sendMessage(remoteJid, { text: 'Este comando solo se puede usar en grupos.' }, { quoted: msg });
        }

        try {
            // 2. Obtener la información (metadata) del grupo
            const groupMetadata = await sock.groupMetadata(remoteJid);
            
            // 3. Crear una lista con los JIDs (IDs de usuario) de todos los participantes
            const participants = groupMetadata.participants.map(p => p.id);

            // 4. Determinar qué mensaje se va a enviar
            const quoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
            const messageText = args.join(' ');

            // Si no hay mensaje escrito ni mensaje citado, enviar un aviso.
            if (!quoted && !messageText) {
                return sock.sendMessage(remoteJid, { text: 'Debes escribir un mensaje o responder a uno para usar este comando.\n\nEjemplo:\n.tag ¡Hola a todos!' }, { quoted: msg });
            }

            // 5. Enviar el mensaje
            if (quoted) {
                // Si se responde a un mensaje (sticker, imagen, video, etc.)
                // Lo reenviamos con las menciones
                await sock.sendMessage(remoteJid, { 
                    forward: { key: msg.message.extendedTextMessage.contextInfo.stanzaId, message: quoted },
                    mentions: participants 
                });

            } else {
                // Si se escribe un mensaje de texto
                await sock.sendMessage(remoteJid, { 
                    text: messageText, 
                    mentions: participants 
                });
            }

        } catch (error) {
            console.error('Error en el comando tag:', error);
            await sock.sendMessage(remoteJid, { text: `Ocurrió un error al intentar mencionar a todos.\n_Error: Asegúrate de que soy administrador del grupo._` }, { quoted: msg });
        }
    }
};