// ./commands/antilink.js
const fs = require('fs');
const path = require('path');

module.exports = {
    name: "antilink",
    aliases: ["antilinks"],
    description: "Activa o desactiva el sistema anti-link en el grupo.",
    
    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;

        // Solo funciona en grupos
        if (!from.endsWith("@g.us")) {
            return sock.sendMessage(from, { text: "❗ Este comando solo se puede usar en grupos." });
        }

        const metadata = await sock.groupMetadata(from);
        const participants = metadata.participants;

        const senderData = participants.find(p => p.id === sender);
        const isSenderAdmin = senderData?.admin !== null;

        if (!isSenderAdmin) {
            return sock.sendMessage(from, {
                text: "⚠️ Solo los *administradores* pueden usar este comando."
            });
        }

        // PATH de la base de datos
        const dbPath = path.join(__dirname, '..', 'antilink-db.json');

        // Crear archivo si no existe
        if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({}, null, 2));

        const db = JSON.parse(fs.readFileSync(dbPath));

        const option = (args[0] || "").toLowerCase();

        if (option === "on") {
            db[from] = true;
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
            return sock.sendMessage(from, {
                text: "🟢 *ANTI-LINK ACTIVADO*\n\nLos enlaces externos ahora serán eliminados."
            });
        }

        if (option === "off") {
            delete db[from];
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
            return sock.sendMessage(from, {
                text: "🔴 *ANTI-LINK DESACTIVADO*\n\nLos usuarios pueden enviar enlaces normalmente."
            });
        }

        // Si no colocó nada
        return sock.sendMessage(from, {
            text: "⚙️ Uso del comando:\n\n`.antilink on`\n`.antilink off`"
        });
    }
};