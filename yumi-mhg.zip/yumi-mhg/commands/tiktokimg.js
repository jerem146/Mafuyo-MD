
// Archivo: commands/tiktokimg.js
const axios = require("axios");

module.exports = {
    name: 'tiktokimg',
    description: 'Descarga imágenes de TikTok (carruseles o miniaturas).',
    aliases: ['ttimg'],
    execute: async (sock, m, args) => {
        const from = m.key.remoteJid;
        const reply = (texto) => sock.sendMessage(from, { text: texto }, { quoted: m });

        if (!args.length) return reply('❀ Por favor, ingresa el enlace de TikTok.');

        const text = args.join(" ");
        const isUrl = /(?:https?:\/\/)?(?:www\.|vm\.|vt\.|t\.)?tiktok\.com\/([^\s&]+)/gi.test(text);

        if (!isUrl) return reply('❀ Ese no parece ser un enlace de TikTok válido.');

        try {
            await sock.sendMessage(from, { react: { text: '🕒', key: m.key } });

            const res = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(text)}?hd=1`);
            const data = res.data?.data;

            if (!data || !data.images || data.images.length === 0) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return reply('❀ No se encontraron imágenes para este TikTok.');
            }

            await reply(`❀ Encontradas ${data.images.length} imágenes. Enviando...`);

            for (const imageUrl of data.images) {
                await sock.sendMessage(from, { image: { url: imageUrl }, caption: `📸 Imagen de TikTok` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '✔️', key: m.key } });

        } catch (e) {
            console.error("Error en tiktokimg:", e);
            await sock.sendMessage(from, { react: { text: '✖️', key: m.key } });
            await reply('⚠︎ Ocurrió un error. Es posible que la API esté fallando o el enlace sea inválido.');
        }
    },
};