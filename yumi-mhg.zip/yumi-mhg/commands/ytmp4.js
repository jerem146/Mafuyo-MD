// /commands/ytmp4.js

const axios = require("axios");

module.exports = {
    // Nombre principal del comando
    name: 'ytmp4',
    // Alias opcionales
    aliases: ['video', 'vid'],
    description: 'Descarga y envía un video de YouTube en formato MP4.',

    /**
     * @param {import('baileys').WASocket} sock
     * @param {import('baileys').WAMessage} msg
     * @param {string[]} args
     */
    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        const reply = (texto) => sock.sendMessage(from, { text: texto }, { quoted: msg });

        try {
            const query = args.join(" ").trim();

            if (!query) {
                return reply(`❌ ¿Qué video quieres descargar?\n\n*Ejemplo:*\n.ytmp4 https://youtu.be/dQw4w9WgXcQ`);
            }

            await sock.sendMessage(from, { react: { text: "⏳", key: msg.key } });

            const youtubeRegex = /(?:https?:\/\/)?(?:www\.)?(?:m\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
            const match = query.match(youtubeRegex);
            const youtubeId = match ? match[1] : null;

            // Construimos la URL de la API de video
            const apiUrlVideo = youtubeId
                ? `https://systemzone.store/api/ytmp4?id=${youtubeId}`
                : `https://systemzone.store/api/ytmp4?text=${encodeURIComponent(query)}`;

            // Hacemos la petición a la API
            const videoApiResult = await axios.get(apiUrlVideo).then(r => r.data).catch(() => null);

            // Si la API falla o no encuentra el video, notificamos al usuario
            if (!videoApiResult || !videoApiResult.status) {
                await sock.sendMessage(from, { react: { text: "❌", key: msg.key } });
                return reply("⚠️ No pude encontrar el video solicitado. Verifica el nombre o el link.");
            }

            const data = videoApiResult;
            const { title = "Sin título", author = "Desconocido", duration = "N/A", thumb } = data;
            
            // Obtenemos directamente la URL de descarga del video
            const downloadUrl = data.download_vid_url;

            // Si la API no proporcionó un link de descarga de VIDEO, notificamos el error
            if (!downloadUrl) {
                await sock.sendMessage(from, { react: { text: "❌", key: msg.key } });
                return reply("❌ La API no proporcionó un link de descarga para el video.");
            }

            // Descargamos el video en un buffer
            const buffer = await axios.get(downloadUrl, { responseType: "arraybuffer" }).then(r => r.data).catch(() => null);

            if (!buffer) {
                await sock.sendMessage(from, { react: { text: "❌", key: msg.key } });
                return reply("❌ Falló la descarga del archivo de video. Puede ser un problema temporal de la API.");
            }

            // Preparamos el mensaje de pie de video
            const caption = `*${title}*\n\n👤 *Autor:* ${author}\n⏱️ *Duración:* ${duration}`;

            // Enviamos el mensaje con el video
            await sock.sendMessage(from, {
                video: buffer,
                mimetype: "video/mp4",
                fileName: `${title.replace(/[^\w\s.-]/gi, "")}.mp4`,
                caption: caption,
                jpegThumbnail: thumb ? (await axios.get(thumb, { responseType: 'arraybuffer' }).then(r => r.data).catch(() => undefined)) : undefined
            }, { quoted: msg });

            // Reaccionamos con éxito
            await sock.sendMessage(from, { react: { text: "✅", key: msg.key } });

        } catch (e) {
            console.error("❌ Error fatal en el comando ytmp4:", e);
            await reply("❌ Ocurrió un error inesperado al procesar tu solicitud.");
        }
    }
};