// Código para commands/ping.js
module.exports = {
    name: 'ping',
    description: 'Responde con Pong!',
    execute: async (sock, m) => {
        // m.key.remoteJid es el chat (usuario o grupo) donde se envió el mensaje
        await sock.sendMessage(m.key.remoteJid, { text: 'Pong! 🏓' }, { quoted: m });
    },
};