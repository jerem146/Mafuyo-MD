// Archivo: commands/ttaudio.js (Nuevo - Solo para audio)

const axios = require("axios");

module.exports = {
    name: 'ttaudio',
    description: 'Descarga el audio de un video de TikTok.',
    aliases: ['tkaudio'],
    execute: async (sock, m, args) => {
        const from = m.key.remoteJid;
        const text = args.join(" ");
        const reply = (texto) => sock.sendMessage(from, { text: texto }, { quoted: m });

        if (!text) return reply('❀ Por favor, ingresa un enlace de TikTok o el nombre del video para extraer su audio.');
        
        const isUrl = /(?:https:?\/{2})?(?:www\.|vm\.|vt\.|t\.)?tiktok\.com\/([^\s&]+)/gi.test(text);

        try {
            await sock.sendMessage(from, { react: { text: '🎵', key: m.key } });
            
            let audioUrl = null;
            let videoTitle = "Audio de TikTok"; // Título por defecto

            // Si es una URL, obtenemos el audio directamente
            if (isUrl) {
                const res = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(text)}?hd=1`);
                audioUrl = res.data?.data?.music;
                videoTitle = res.data?.data?.title || videoTitle;
            // Si es una búsqueda, buscamos el video y luego obtenemos su audio
            } else {
                const res = await axios.post('https://tikwm.com/api/feed/search', { keywords: text, count: 1, cursor: 0, HD: 1 });
                audioUrl = res.data?.data?.videos?.[0]?.music;
                videoTitle = res.data?.data?.videos?.[0]?.title || videoTitle;
            }

            if (!audioUrl) {
                await sock.sendMessage(from, { react: { text: '❓', key: m.key } });
                return reply('ꕥ No se pudo encontrar el audio para este TikTok. Asegúrate de que el enlace o la búsqueda sean correctos.');
            }

            // Enviamos el audio
            await sock.sendMessage(from, {
                audio: { url: audioUrl },
                mimetype: 'audio/mp4',
                fileName: `${videoTitle}.mp4`
            }, { quoted: m });

            await sock.sendMessage(from, { react: { text: '✔️', key: m.key } });

        } catch (e) {
            console.error("Error en el comando ttaudio:", e);
            await sock.sendMessage(from, { react: { text: '✖️', key: m.key } });
            await reply(`⚠︎ Ocurrió un error al intentar obtener el audio.`);
        }
    },
};