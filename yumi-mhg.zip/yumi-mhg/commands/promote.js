// commands/promote.js
module.exports = {
    name: "promote",
    aliases: ["daradmin", "ascender"],

    async execute(sock, msg, args) {
        try {
            const from = msg.key.remoteJid;
            if (!from.endsWith("@g.us"))
                return await sock.sendMessage(from, { text: "❀ Este comando solo puede usarse en grupos." });

            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants;

            const botNumber = sock.user.id.split(":")[0] + "@s.whatsapp.net";
            const isBotAdmin = participants.find(p => p.id === botNumber)?.admin !== null;

            const sender = msg.key.participant || msg.key.remoteJid;
            const isSenderAdmin = participants.find(p => p.id === sender)?.admin !== null;

            // Verificación
            if (!isSenderAdmin)
                return await sock.sendMessage(from, { text: "❀ Solo un administrador puede ascender a alguien." });

            if (!isBotAdmin)
                return await sock.sendMessage(from, { text: "❀ No puedo ascender a alguien si no soy administrador." });

            // Determinar el objetivo
            let target;

            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
                // @mención
                target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];

            } else if (msg.message?.extendedTextMessage?.contextInfo?.participant && msg.message.extendedTextMessage.contextInfo.quotedMessage) {
                // Respondiendo mensaje (quoted)
                target = msg.message.extendedTextMessage.contextInfo.participant;

            } else if (args[0]) {
                // Número
                target = args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";

            } else {
                return await sock.sendMessage(from, { text: `❀ Menciona, responde o coloca el número del usuario a ascender.` });
            }

            // Ascender
            await sock.groupParticipantsUpdate(from, [target], "promote");

            // Enviar mensaje bonito
            await sock.sendMessage(from, {
                text:
`✨ *Usuario ascendido exitosamente*

👤 *Ascendido:* @${target.split("@")[0]}
🛡 *Ejecutado por:* @${sender.split("@")[0]}

❀ El poder ha cambiado de manos.`,
                mentions: [target, sender]
            });

        } catch (e) {
            console.error("Error en promote:", e);
        }
    }
};