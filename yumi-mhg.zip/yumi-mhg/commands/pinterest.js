// /commands/pinterest.js

const axios = require('axios');

// La misma API Key que usa tu comando de música
const API_KEY_TED = "tedzinho";

module.exports = {
    // Nombre principal del comando
    name: 'pinterest',
    // Alias para el comando
    aliases: ['pin', 'psearch'],
    description: 'Busca y envía 3 imágenes aleatorias de Pinterest.',

    /**
     * @param {import('baileys').WASocket} sock
     * @param {import('baileys').WAMessage} msg
     * @param {string[]} args
     */
    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        const reply = (texto) => sock.sendMessage(from, { text: texto }, { quoted: msg });

        try {
            const query = args.join(" ").trim();
            if (!query) return reply(`❌ ¿Qué quieres buscar en Pinterest?\n\n*Ejemplo:*\n.pinterest Gatos con sombrero`);
            
            // Reaccionamos para dar feedback al usuario
            await sock.sendMessage(from, { react: { text: "🎨", key: msg.key } });

            // Llamamos a la API de Tedzinho para la búsqueda en Pinterest
            const searchApi = await axios.get(
                `https://tedzinho.com.br/api/pesquisa/pinterest?apikey=${API_KEY_TED}&query=${encodeURIComponent(query)}`
            ).then(res => res.data)
            .catch(() => null);

            // Verificamos si la API devolvió resultados válidos
            if (!searchApi || searchApi.status !== "OK" || !searchApi.resultado || searchApi.resultado.length === 0) {
                await sock.sendMessage(from, { react: { text: "❌", key: msg.key } });
                return reply("⚠️ No encontré ningún resultado para tu búsqueda en Pinterest.");
            }

            // Mezclamos los resultados y seleccionamos los primeros 3
            const shuffled = searchApi.resultado.sort(() => 0.5 - Math.random());
            const selected = shuffled.slice(0, 3);

            // Función para crear un retraso (delay)
            const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

            await reply(`✅ ¡Encontré ${searchApi.resultado.length} imágenes! Enviando 3 al azar...`);
            
            // Hacemos un bucle para enviar cada una de las 3 imágenes seleccionadas
            for (const item of selected) {
                const caption = `👤 *Autor:* ${item.fullname} (${item.by})\n📝 *Descripción:* ${item.caption || "Sin descripción"}\n🔗 *Fuente:* ${item.source}`;

                await sock.sendMessage(from, {
                    image: { url: item.image },
                    caption: caption
                }, { quoted: msg });

                // Esperamos 2 segundos antes de enviar la siguiente imagen
                await wait(2000);
            }

            // Reaccionamos con éxito al final
            await sock.sendMessage(from, { react: { text: "✅", key: msg.key } });

        } catch (e) {
            console.error("❌ Error fatal en el comando pinterest:", e);
            await reply("❌ Ocurrió un error inesperado al buscar las imágenes.");
        }
    }
};