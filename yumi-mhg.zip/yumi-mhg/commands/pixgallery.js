// /commands/pixgallery.js

const axios = require('axios');
// Tu index.js usa 'baileys', así que importamos desde ahí
const { downloadContentFromMessage } = require('baileys');
const FormData = require('form-data');

module.exports = {
    // Nombre principal del comando
    name: 'pixgallery',
    // Alias para el comando
    aliases: ['pixgal', 'subir'],
    description: 'Sube una imagen a una galería de Pixhost.to y envía el enlace.',

    /**
     * @param {import('baileys').WASocket} sock
     * @param {import('baileys').WAMessage} msg
     * @param {string[]} args
     */
    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        const reply = (texto) => sock.sendMessage(from, { text: texto }, { quoted: msg });

        try {
            // Verificamos si el mensaje actual es una imagen O si está citando un mensaje con una imagen
            const isQuotedImage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
            const isImage = msg.message?.imageMessage;

            if (!isQuotedImage && !isImage) {
                return reply(`❌ Tienes que enviar o responder a una imagen con este comando.\n\n*Ejemplo:*\nEnvía una imagen y pon en el texto ".pixgallery" o responde a una imagen con el mismo comando.`);
            }
            
            await sock.sendMessage(from, { react: { text: "⏳", key: msg.key } });

            // El nombre de la galería se toma de los argumentos, o se usa uno por defecto
            const galleryName = args.join(' ').trim() || 'Galería de WhatsApp';
            await reply(`⏳ Creando galería "${galleryName}" y subiendo la imagen...`);

            // --- 1. Crear la galería en Pixhost ---
            const galleryResponse = await axios.post('https://api.pixhost.to/galleries',
                `gallery_name=${encodeURIComponent(galleryName)}`, {
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' }
                }
            );
            const { gallery_hash, gallery_upload_hash } = galleryResponse.data;

            // --- 2. Descargar la imagen de WhatsApp ---
            const imageMessage = isQuotedImage ? isQuotedImage : isImage;
            const stream = await downloadContentFromMessage(imageMessage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // --- 3. Subir la imagen a la galería creada ---
            const form = new FormData();
            form.append('img', buffer, { filename: 'image.jpg', contentType: 'image/jpeg' });
            form.append('content_type', '0'); // '0' para contenido seguro/apto para todos
            form.append('gallery_hash', gallery_hash);
            form.append('gallery_upload_hash', gallery_upload_hash);

            const uploadResponse = await axios.post('https://api.pixhost.to/images', form, {
                headers: { ...form.getHeaders(), 'Accept': 'application/json' }
            });
            const { show_url, th_url } = uploadResponse.data;

            if (!show_url) throw new Error("La API de Pixhost no devolvió un enlace para la imagen.");

            // --- 4. Finalizar la galería (cerrarla para nuevas subidas) ---
            await axios.post(`https://api.pixhost.to/galleries/${gallery_hash}/finalize`,
                `gallery_upload_hash=${gallery_upload_hash}`, {
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' }
                }
            );

            // --- 5. Enviar el resultado al usuario ---
            const thumbnailBuffer = await axios.get(th_url, { responseType: 'arraybuffer' }).then(r => r.data).catch(() => null);
            
            const finalMessage = `✅ *¡Galería creada con éxito!*\n\n` +
                                 `🔗 *Enlace directo:* ${show_url}\n` +
                                 `🖼️ *Miniatura:* ${th_url}`;

            if (thumbnailBuffer) {
                await sock.sendMessage(from, { image: thumbnailBuffer, caption: finalMessage }, { quoted: msg });
            } else {
                await reply(finalMessage);
            }

            await sock.sendMessage(from, { react: { text: "✅", key: msg.key } });

        } catch (e) {
            console.error("❌ Error fatal en el comando pixgallery:", e.message);
            let errorMsg = "❌ Ocurrió un error al crear la galería.";

            // Manejo de errores específicos de la API de Pixhost
            if (e.response?.status) {
                switch (e.response.status) {
                    case 400: errorMsg = "❌ Solicitud inválida."; break;
                    case 413: errorMsg = "❌ ¡La imagen es muy grande! El tamaño máximo es de 10 MB."; break;
                    case 414: errorMsg = "❌ Formato de archivo no soportado. Usa JPG, PNG o GIF."; break;
                    case 500: errorMsg = "❌ Error en el servidor de Pixhost. Inténtalo de nuevo más tarde."; break;
                }
            }
            await reply(errorMsg);
        }
    }
};