const fs = require("fs");
const path = require("path");

const muteDB = path.join(__dirname, "../mute-db.json");

if (!fs.existsSync(muteDB)) fs.writeFileSync(muteDB, JSON.stringify({}));

module.exports = {
    name: "unmute",
    aliases: ["desmutear", "permitir"],
    description: "Quita el mute de un participante",

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;

        if (!from.endsWith("@g.us")) {
            return sock.sendMessage(from, { text: "❌ Este comando solo funciona en grupos." });
        }

        // Obtener información del grupo
        const metadata = await sock.groupMetadata(from);
        const participants = metadata.participants;

        const sender = msg.key.participant;
        const isAdmin = participants.find(p => p.id === sender)?.admin !== null;

        if (!isAdmin) {
            return sock.sendMessage(from, { text: "😿 *Debes ser administrador para usar este comando.*" });
        }

        // ================================
        //  OBTENER USUARIO: Mention o Reply
        // ================================
        let target =
            msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
            msg.message?.extendedTextMessage?.contextInfo?.participant;

        if (!target) {
            return sock.sendMessage(from, {
                text: "⚠️ Debes mencionar o responder un mensaje.\nEjemplo:\n.unmute @usuario"
            });
        }

        // Cargar base
        const db = JSON.parse(fs.readFileSync(muteDB));

        if (!db[from] || !db[from][target]) {
            return sock.sendMessage(from, {
                text: `✨ *@${target.split("@")[0]}* no está muteado.`,
                mentions: [target]
            });
        }

        // Eliminar mute
        db[from][target].muted = false;
        db[from][target].strikes = 0;
        db[from][target].warned = false;

        fs.writeFileSync(muteDB, JSON.stringify(db, null, 2));

        await sock.sendMessage(from, {
            text: `🔊 Usuario desmuteado:\n@${target.split("@")[0]}`,
            mentions: [target]
        });
    }
};