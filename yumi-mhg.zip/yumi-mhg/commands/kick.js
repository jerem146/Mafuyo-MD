// commands/kick.js
module.exports = {
    name: "kick",
    aliases: ["ban", "expulsar"],
    description: "Expulsa a un participante (etiquetado o respondiendo).",

    async execute(sock, msg, args) {
        try {
            const from = msg.key.remoteJid;

            // Solo grupos
            if (!from.endsWith("@g.us")) {
                return sock.sendMessage(from, { text: "⚠️ Este comando solo funciona en grupos." });
            }

            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants;

            const botId = sock.user.id.split(":")[0] + "@s.whatsapp.net";
            const botIsAdmin = participants.find(p => p.id === botId)?.admin !== null;

            if (!botIsAdmin) {
                return sock.sendMessage(from, { text: "😿 No tengo permisos de administrador." });
            }

            const sender = msg.key.participant;
            const senderIsAdmin = participants.find(p => p.id === sender)?.admin !== null;

            if (!senderIsAdmin) {
                return sock.sendMessage(from, { text: "⚠️ Solo los administradores pueden usar este comando." });
            }

            // ============================================
            //         OBTENER USUARIO OBJETIVO
            // ============================================

            let target;

            // 1. Si el mensaje es respuesta
            if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
                target = msg.message.extendedTextMessage.contextInfo.participant;
            }

            // 2. Si viene etiquetado
            else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
            }

            // 3. Si no hay objetivo
            else {
                return sock.sendMessage(from, { 
                    text: `⚠️ Debes etiquetar o responder a alguien.\n\nEjemplos:\n• .kick @usuario\n• Responde su mensaje con .kick` 
                });
            }

            // Evitar expulsar admins
            const targetIsAdmin = participants.find(p => p.id === target)?.admin !== null;
            if (targetIsAdmin) {
                return sock.sendMessage(from, { 
                    text: `❌ No puedo expulsar a administradores.` 
                });
            }

            // EXPULSIÓN
            await sock.groupParticipantsUpdate(from, [target], "remove");

            // MENSAJE ELEGANTE
            return sock.sendMessage(from, {
                text: `🚫 *Usuario expulsado*\n\n👤 *@${target.split("@")[0]}* fue removido del grupo.`,
                mentions: [target]
            });

        } catch (error) {
            console.error("Error en comando kick:", error);
            return sock.sendMessage(msg.key.remoteJid, { text: "⚠️ Ocurrió un error al intentar expulsar." });
        }
    }
};