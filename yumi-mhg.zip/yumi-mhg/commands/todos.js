// commands/tagall.js

module.exports = {
    name: "tagall",
    aliases: ["todos", "invocar", "revivan"],
    description: "Mención general con diseño elegante",

    async execute(sock, msg, args) {

        const from = msg.key.remoteJid;

        if (!from.endsWith("@g.us")) {
            return sock.sendMessage(from, { text: "❌ Este comando solo puede usarse en grupos." }, { quoted: msg });
        }

        const metadata = await sock.groupMetadata(from);
        const participants = metadata.participants;
        const sender = msg.key.participant || msg.key.remoteJid;

        // Verificar admins
        const admins = participants
            .filter(p => p.admin === "admin" || p.admin === "superadmin")
            .map(p => p.id);

        if (!admins.includes(sender)) {
            return sock.sendMessage(from, { text: "⚠️ Solo *administradores* pueden usar este comando." }, { quoted: msg });
        }

        const texto = args.length ? args.join(" ") : "Sin mensaje adicional";

        // Cabecera + mensaje
        let teks = `*!  MENCION GENERAL  !*\n`;
        teks += `  *PARA ${participants.length} MIEMBROS* 🗣️\n\n`;
        teks += `*» INFO :* ${texto}\n\n`;

        // Encabezado decorado
        teks += `╭  ┄ 𝅄 ۪꒰ \`⡞᪲=͟͟͞𝑪𝑨𝑹𝑳𝒀 𝑩𝑶𝑻≼᳞ׄ\` ꒱ ۟ 𝅄 ┄\n`;

        // Listado de números en fila
        for (const mem of participants) {
            const numero = mem.id.split("@")[0];
            teks += `┊ꕥ @${numero}\n`;
        }

        // Footer decorado
        teks += `╰⸼ ┄ ┄ ┄ ─  ꒰  ׅ୭ *v1.0* ୧ ׅ ꒱  ┄  ─ ┄⸼`;

        // Enviar mensaje con menciones
        await sock.sendMessage(from, {
            text: teks,
            mentions: participants.map(user => user.id)
        }, { quoted: msg });
    }
};