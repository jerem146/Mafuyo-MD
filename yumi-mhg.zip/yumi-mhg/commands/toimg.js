// ARCHIVO: commands/toimg.js (CORREGIDO - VERSIÓN FINAL)

const { downloadContentFromMessage } = require('baileys');
const { exec } = require('child_process');
const fs = require('fs/promises');
const path = require('path');
const { tmpdir } = require('os');
const crypto = require('crypto');

/**
 * Genera un nombre de archivo aleatorio para los archivos temporales.
 * @param {string} ext - La extensión del archivo.
 * @returns {string} - La ruta completa al archivo temporal.
 */
const getRandomTmpFile = (ext) => {
    const randomName = crypto.randomBytes(12).toString('hex');
    return path.join(tmpdir(), `${randomName}.${ext}`);
};

module.exports = {
    name: 'toimg',
    aliases: ['toimage'],
    description: 'Convierte un sticker (estático o animado) a una imagen o video.',
    async execute(sock, msg, args) {
        const quoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.stickerMessage) {
            return sock.sendMessage(msg.key.remoteJid, { text: 'Por favor, responde a un sticker con este comando para convertirlo.' }, { quoted: msg });
        }

        const inputPath = getRandomTmpFile('webp');
        let outputPath;

        try {
            const stream = await downloadContentFromMessage(quoted.stickerMessage, 'sticker');
            
            let buffer = Buffer.from([]); 
            
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            await fs.writeFile(inputPath, buffer);

            const isAnimated = quoted.stickerMessage.isAnimated;

            if (isAnimated) {
                outputPath = getRandomTmpFile('mp4');
                const cmd = `ffmpeg -i "${inputPath}" -vf "pix_fmt=yuv420p" -y "${outputPath}"`;
                await new Promise((resolve, reject) => exec(cmd, (err) => (err ? reject(err) : resolve())));

                const videoBuffer = await fs.readFile(outputPath);
                await sock.sendMessage(msg.key.remoteJid, {
                    video: videoBuffer,
                    caption: '¡Sticker animado convertido a video!',
                    gifPlayback: true
                }, { quoted: msg });
            } else {
                outputPath = getRandomTmpFile('png');
                const cmd = `ffmpeg -i "${inputPath}" -y "${outputPath}"`;
                await new Promise((resolve, reject) => exec(cmd, (err) => (err ? reject(err) : resolve())));

                const imageBuffer = await fs.readFile(outputPath);
                await sock.sendMessage(msg.key.remoteJid, {
                    image: imageBuffer,
                    caption: '¡Sticker convertido a imagen!'
                }, { quoted: msg });
            }
        } catch (error) {
            console.error('Error en el comando toimg:', error);
            await sock.sendMessage(msg.key.remoteJid, { text: `Ocurrió un error al convertir el sticker.\n_Error: ${error.message}_` }, { quoted: msg });
        } finally {
            await Promise.all([
                fs.unlink(inputPath).catch(() => {}),
                outputPath ? fs.unlink(outputPath).catch(() => {}) : Promise.resolve()
            ]);
        }
    } // <-- Esta es la llave de cierre para la función 'execute'
}; // <-- ESTA ES LA LLAVE QUE FALTABA